const { contextBridge, ipcRenderer, shell } = require("electron");

contextBridge.exposeInMainWorld("electronAPI", {
  generateHTML: (data) => ipcRenderer.send("generate-html", data),
  onSuccess: (callback) => ipcRenderer.on("generation-success", callback),
  onCancelled: (callback) => ipcRenderer.on("generation-cancelled", callback),
  openExternal: (url) => shell.openExternal(url)
});
