// Open external links in the default browser
document.addEventListener("click", (event) => {
  if (event.target.tagName === "A" && event.target.href.startsWith("http")) {
    event.preventDefault();
    window.electronAPI.openExternal(event.target.href);
  }
});

function getInputValue(id, defaultValue = "") {
  const el = document.getElementById(id);
  return el ? el.value : defaultValue;
}

// Convert hex + opacity to rgba
function hexToRgba(hex, opacityPercent) {
  const hexClean = hex.replace("#", "");
  const r = parseInt(hexClean.substring(0, 2), 16);
  const g = parseInt(hexClean.substring(2, 4), 16);
  const b = parseInt(hexClean.substring(4, 6), 16);
  const a = (opacityPercent / 100).toFixed(2);
  return `rgba(${r},${g},${b},${a})`;
}

function gatherInput() {
  const rawToken = getInputValue("oauthToken").trim();
  return {
    twitchInfo: {
      username: getInputValue("botUsername"),
      oauth: rawToken.startsWith("oauth:") ? rawToken : `oauth:${rawToken}`,
      channel: getInputValue("channelName")
    },
    colors: {
      TIMER_TEXT_COLOR: getInputValue("pomodoro_timer_text_color", "#ffffff"),
      TIMER_BG_COLOR: hexToRgba(
        getInputValue("pomodoro_timer_bg_color", "#000000"),
        getInputValue("pomodoro_timer_bg_opacity", 100)
      ),
      TASK_DISPLAY_BG_COLOR: hexToRgba(
        getInputValue("pomodoro_task_display_bg_color", "#303626"),
        getInputValue("pomodoro_task_display_bg_opacity", 100)
      ),
      SIDEBAR_BG_COLOR: hexToRgba(
        getInputValue("taskboard_sidebar_bg_color", "#600000"),
        getInputValue("taskboard_sidebar_bg_opacity", 100)
      ),
      TASK_BG_COLOR: hexToRgba(
        getInputValue("taskboard_task_bg_color", "#500000"),
        getInputValue("taskboard_task_bg_opacity", 100)
      ),
      CURRENT_TASK_COLOR: getInputValue("taskboard_current_task_color", "#b40000"),
      FINISHED_TASK_COLOR: getInputValue("taskboard_finished_task_color", "#005000"),
      TEXT_COLOR: getInputValue("taskboard_text_color", "#ffffff")
    }
  };
}

// Button event listeners
document.getElementById("generatePomodoro").addEventListener("click", () => {
  const data = gatherInput();
  window.electronAPI.generateHTML({ templateType: "pomodoro", ...data });
});

document.getElementById("generateTaskboard").addEventListener("click", () => {
  const data = gatherInput();
  window.electronAPI.generateHTML({ templateType: "taskboard", ...data });
});

// Listen for success/cancel
window.electronAPI.onSuccess((event, type) => alert(`${type} HTML generated successfully!`));
window.electronAPI.onCancelled((event, type) => alert(`${type} HTML generation cancelled.`));

document.addEventListener("DOMContentLoaded", () => {
  const transparencyPairs = [
    "pomodoro_timer_bg",
    "pomodoro_task_display_bg",
    "taskboard_sidebar_bg",
    "taskboard_task_bg"
  ];

  transparencyPairs.forEach(id => {
    const slider = document.getElementById(`${id}_opacity`);
    const label = document.getElementById(`${id}_value`);

    if (!slider || !label) {
      console.warn(`Missing elements for ${id}`);
      return;
    }

    // Initialize
    label.textContent = `${slider.value}%`;

    // Update on input
    slider.addEventListener("input", () => {
      label.textContent = `${slider.value}%`;
    });
  });
});
