const { app, BrowserWindow, ipcMain, dialog } = require("electron");
const fs = require("fs");
const path = require("path");

function createWindow() {
  const win = new BrowserWindow({
    width: 600,
    height: 700,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  win.loadFile("index.html");
}


app.whenReady().then(createWindow);

// Keep your existing ipcMain handler here
ipcMain.on("generate-html", (event, data) => {
  const { templateType, twitchInfo, colors } = data;
  const templatePath = path.join(__dirname, "templates", templateType + ".html");
  let templateContent = fs.readFileSync(templatePath, "utf-8");

  // Replace Twitch placeholders
  templateContent = templateContent
    .replace(/__BOT_USERNAME__/g, twitchInfo.username)
    .replace(/__OAUTH_TOKEN__/g, twitchInfo.oauth)
    .replace(/__CHANNEL_NAME__/g, twitchInfo.channel);

  // Replace CSS color placeholders
  for (const [key, value] of Object.entries(colors)) {
    const regex = new RegExp(`__${key.toUpperCase()}__`, "g");
    templateContent = templateContent.replace(regex, value);
  }

  const savePath = dialog.showSaveDialogSync({
    title: `Save ${templateType}.html`,
    defaultPath: `${templateType}.html`,
    filters: [{ name: "HTML Files", extensions: ["html"] }]
  });

  if (savePath) {
    fs.writeFileSync(savePath, templateContent, "utf-8");
    event.sender.send("generation-success", templateType);
  } else {
    event.sender.send("generation-cancelled", templateType);
  }
});
